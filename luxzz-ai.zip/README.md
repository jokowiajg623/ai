# Luxzz-AI

**Intelligent Without Limits**

A production-ready AI chat platform built with Next.js 14, Prisma, PostgreSQL, and OpenRouter.

---

## Stack

- **Framework**: Next.js 14 (App Router)
- **Styling**: TailwindCSS
- **Database**: PostgreSQL + Prisma ORM
- **Auth**: Custom JWT (jose) + bcryptjs
- **AI**: OpenRouter API (streaming)
- **Deploy**: Vercel-ready

---

## Quick Start

### 1. Clone & Install

```bash
git clone <your-repo>
cd luxzz-ai
npm install
```

### 2. Environment Variables

```bash
cp .env.example .env
```

Fill in your `.env`:

```env
DATABASE_URL="postgresql://user:password@localhost:5432/luxzz_ai"
AUTH_SECRET="your-super-secret-key-min-32-chars"
OPENROUTER_API_KEY="sk-or-v1-your-key-here"
NEXT_PUBLIC_APP_URL="http://localhost:3000"
```

### 3. Database Setup

```bash
npm run db:push
npm run db:seed
```

Default admin credentials after seeding:
- **Email**: admin@luxzz-ai.com
- **Password**: Admin123!

### 4. Run

```bash
npm run dev
```

---

## Deploy to Vercel

1. Push to GitHub
2. Import project in Vercel
3. Add environment variables in Vercel dashboard
4. Set up a PostgreSQL database (Vercel Postgres, Supabase, or Neon)
5. Deploy

---

## Features

- JWT-based authentication (register, login, logout)
- Role-based access: `USER` and `ADMIN`
- Streaming AI responses via OpenRouter
- Multiple chat sessions with rename & delete
- Chat history persisted to PostgreSQL
- Admin panel: model selection, system prompt, temperature
- Rate limiting (20 requests/minute per user)
- Input validation via Zod
- Mobile-responsive dark UI (black + purple theme)

---

## Project Structure

```
luxzz-ai/
├── app/
│   ├── (auth)/
│   │   ├── login/page.tsx
│   │   └── register/page.tsx
│   ├── (dashboard)/
│   │   ├── chat/page.tsx
│   │   └── admin/page.tsx
│   ├── api/
│   │   ├── auth/login, register, logout, me
│   │   ├── chat/route.ts          ← streaming endpoint
│   │   ├── sessions/route.ts
│   │   ├── sessions/[id]/route.ts
│   │   └── admin/settings, analytics
│   ├── globals.css
│   └── layout.tsx
├── components/
│   ├── auth/LoginForm, RegisterForm
│   ├── chat/DashboardShell, ChatInterface, MessageBubble, TypingIndicator
│   └── admin/AdminPanel
├── lib/
│   ├── auth.ts         ← JWT session management
│   ├── openrouter.ts   ← API integration with retry/timeout
│   ├── prisma.ts       ← singleton client
│   ├── ratelimit.ts    ← in-memory rate limiter
│   └── settings.ts     ← DB-backed settings
├── prisma/
│   ├── schema.prisma
│   └── seed.ts
└── middleware.ts        ← route protection
```

---

## Support

Telegram: [t.me/cloudakamai](https://t.me/cloudakamai)
