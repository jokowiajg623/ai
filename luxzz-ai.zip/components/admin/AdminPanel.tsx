"use client";

import { useState } from "react";
import { DEFAULT_MODELS } from "@/lib/openrouter";

interface AdminPanelProps {
  initialSettings: Record<string, string>;
  stats: {
    totalUsers: number;
    totalSessions: number;
    totalMessages: number;
  };
}

export function AdminPanel({ initialSettings, stats }: AdminPanelProps) {
  const [settings, setSettings] = useState(initialSettings);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState<"settings" | "analytics">("settings");

  async function saveSettings() {
    setSaving(true);
    setError("");
    setSaved(false);

    try {
      const res = await fetch("/api/admin/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemPrompt: settings.systemPrompt,
          model: settings.model,
          temperature: parseFloat(settings.temperature),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to save settings");
        return;
      }

      setSettings(data.settings);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  const statCards = [
    {
      label: "Total Users",
      value: stats.totalUsers,
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
          <circle cx="9" cy="7" r="4"/>
          <path d="M23 21v-2a4 4 0 00-3-3.87"/>
          <path d="M16 3.13a4 4 0 010 7.75"/>
        </svg>
      ),
    },
    {
      label: "Total Conversations",
      value: stats.totalSessions,
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
        </svg>
      ),
    },
    {
      label: "Total Messages",
      value: stats.totalMessages,
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/>
        </svg>
      ),
    },
  ];

  return (
    <div className="flex flex-col h-full overflow-y-auto bg-[#0f0f14]">
      <div className="max-w-4xl mx-auto w-full px-6 py-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
          <p className="text-[#6b7280] text-sm mt-1">Manage AI settings and view platform analytics</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          {statCards.map((card) => (
            <div
              key={card.label}
              className="bg-[#181824] border border-[#2a2a3a] rounded-2xl p-5 hover:border-[#7c3aed]/30 transition-all duration-200"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="text-[#7c3aed]">{card.icon}</div>
                <span className="text-2xl font-bold text-white">
                  {card.value.toLocaleString()}
                </span>
              </div>
              <p className="text-[#6b7280] text-sm">{card.label}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 bg-[#181824] border border-[#2a2a3a] rounded-xl p-1 w-fit">
          {(["settings", "analytics"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all duration-200 ${
                activeTab === tab
                  ? "bg-[#7c3aed] text-white"
                  : "text-[#6b7280] hover:text-white"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Settings Tab */}
        {activeTab === "settings" && (
          <div className="space-y-5 animate-fade-in">
            {/* System Prompt */}
            <div className="bg-[#181824] border border-[#2a2a3a] rounded-2xl p-5">
              <h3 className="text-white font-semibold mb-1">System Prompt</h3>
              <p className="text-[#6b7280] text-xs mb-3">
                Define the AI&apos;s personality and behavior for all users.
              </p>
              <textarea
                value={settings.systemPrompt || ""}
                onChange={(e) =>
                  setSettings((prev) => ({ ...prev, systemPrompt: e.target.value }))
                }
                rows={6}
                className="w-full bg-[#0f0f14] border border-[#2a2a3a] rounded-xl px-4 py-3 text-[#e5e7eb] placeholder-[#4b5563] focus:outline-none focus:border-[#7c3aed] focus:ring-1 focus:ring-[#7c3aed] transition-all duration-200 text-sm resize-none leading-relaxed"
                placeholder="You are a helpful AI assistant..."
              />
            </div>

            {/* Model Selection */}
            <div className="bg-[#181824] border border-[#2a2a3a] rounded-2xl p-5">
              <h3 className="text-white font-semibold mb-1">AI Model</h3>
              <p className="text-[#6b7280] text-xs mb-3">
                Select the OpenRouter model to power conversations.
              </p>
              <select
                value={settings.model || "openai/gpt-4o-mini"}
                onChange={(e) =>
                  setSettings((prev) => ({ ...prev, model: e.target.value }))
                }
                className="w-full bg-[#0f0f14] border border-[#2a2a3a] rounded-xl px-4 py-3 text-[#e5e7eb] focus:outline-none focus:border-[#7c3aed] focus:ring-1 focus:ring-[#7c3aed] transition-all duration-200 text-sm cursor-pointer"
              >
                {DEFAULT_MODELS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name} — {m.id}
                  </option>
                ))}
              </select>
            </div>

            {/* Temperature */}
            <div className="bg-[#181824] border border-[#2a2a3a] rounded-2xl p-5">
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-white font-semibold">Temperature</h3>
                <span className="text-[#7c3aed] font-mono text-sm font-bold">
                  {parseFloat(settings.temperature || "0.7").toFixed(1)}
                </span>
              </div>
              <p className="text-[#6b7280] text-xs mb-4">
                Lower = more focused and deterministic. Higher = more creative and varied.
              </p>
              <input
                type="range"
                min="0"
                max="2"
                step="0.1"
                value={settings.temperature || "0.7"}
                onChange={(e) =>
                  setSettings((prev) => ({ ...prev, temperature: e.target.value }))
                }
                className="w-full accent-[#7c3aed] cursor-pointer"
              />
              <div className="flex justify-between text-xs text-[#4b5563] mt-1">
                <span>Precise (0.0)</span>
                <span>Balanced (1.0)</span>
                <span>Creative (2.0)</span>
              </div>
            </div>

            {/* Save Button */}
            <div className="flex items-center gap-3">
              <button
                onClick={saveSettings}
                disabled={saving}
                className="flex items-center gap-2 bg-[#7c3aed] hover:bg-[#9333ea] disabled:opacity-60 disabled:cursor-not-allowed text-white px-6 py-3 rounded-xl font-medium text-sm transition-all duration-200 active:scale-95"
              >
                {saving ? (
                  <>
                    <svg className="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M21 12a9 9 0 11-6.219-8.56"/>
                    </svg>
                    Saving...
                  </>
                ) : (
                  <>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/>
                      <polyline points="17 21 17 13 7 13 7 21"/>
                      <polyline points="7 3 7 8 15 8"/>
                    </svg>
                    Save Settings
                  </>
                )}
              </button>

              {saved && (
                <div className="flex items-center gap-1.5 text-emerald-400 text-sm animate-fade-in">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <polyline points="20 6 9 17 4 12"/>
                  </svg>
                  Settings saved successfully
                </div>
              )}

              {error && (
                <div className="flex items-center gap-1.5 text-red-400 text-sm animate-fade-in">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="8" x2="12" y2="12"/>
                    <line x1="12" y1="16" x2="12.01" y2="16"/>
                  </svg>
                  {error}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === "analytics" && (
          <div className="animate-fade-in">
            <div className="bg-[#181824] border border-[#2a2a3a] rounded-2xl p-6">
              <h3 className="text-white font-semibold mb-2">Platform Overview</h3>
              <p className="text-[#6b7280] text-sm mb-6">
                Summary of platform usage and activity.
              </p>

              <div className="space-y-4">
                <div className="flex items-center justify-between py-3 border-b border-[#2a2a3a]">
                  <span className="text-[#9ca3af] text-sm">Average messages per session</span>
                  <span className="text-white font-medium">
                    {stats.totalSessions > 0
                      ? (stats.totalMessages / stats.totalSessions).toFixed(1)
                      : "0"}
                  </span>
                </div>
                <div className="flex items-center justify-between py-3 border-b border-[#2a2a3a]">
                  <span className="text-[#9ca3af] text-sm">Average sessions per user</span>
                  <span className="text-white font-medium">
                    {stats.totalUsers > 0
                      ? (stats.totalSessions / stats.totalUsers).toFixed(1)
                      : "0"}
                  </span>
                </div>
                <div className="flex items-center justify-between py-3">
                  <span className="text-[#9ca3af] text-sm">Active model</span>
                  <span className="text-[#7c3aed] font-medium text-sm">{settings.model}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 bg-[#181824] border border-[#2a2a3a] rounded-2xl p-6">
              <h3 className="text-white font-semibold mb-2">Current Configuration</h3>
              <div className="space-y-3 mt-4">
                <div className="flex items-start gap-3">
                  <span className="text-[#4b5563] text-xs uppercase tracking-wide w-24 flex-shrink-0 mt-0.5">Model</span>
                  <code className="text-[#7c3aed] text-xs bg-[#7c3aed]/10 px-2 py-1 rounded-lg">{settings.model}</code>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[#4b5563] text-xs uppercase tracking-wide w-24 flex-shrink-0 mt-0.5">Temperature</span>
                  <code className="text-[#7c3aed] text-xs bg-[#7c3aed]/10 px-2 py-1 rounded-lg">{settings.temperature}</code>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-[#4b5563] text-xs uppercase tracking-wide w-24 flex-shrink-0 mt-0.5">System</span>
                  <p className="text-[#9ca3af] text-xs leading-relaxed line-clamp-3">{settings.systemPrompt}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
