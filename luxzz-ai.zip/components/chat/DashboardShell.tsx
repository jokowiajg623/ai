"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { SessionPayload } from "@/lib/auth";

interface ChatSession {
  id: string;
  title: string;
  updatedAt: string;
  _count: { messages: number };
}

interface DashboardShellProps {
  session: SessionPayload;
  children: React.ReactNode;
}

export function DashboardShell({ session, children }: DashboardShellProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const activeSessionId = searchParams.get("session");

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [loadingSessions, setLoadingSessions] = useState(true);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");

  useEffect(() => {
    loadSessions();
  }, [pathname, activeSessionId]);

  async function loadSessions() {
    try {
      const res = await fetch("/api/sessions");
      if (res.ok) {
        const data = await res.json();
        setSessions(data.sessions);
      }
    } catch {
      // silently fail
    } finally {
      setLoadingSessions(false);
    }
  }

  async function createSession() {
    try {
      const res = await fetch("/api/sessions", { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        await loadSessions();
        router.push(`/chat?session=${data.session.id}`);
      }
    } catch {}
  }

  async function deleteSession(id: string, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!confirm("Delete this conversation?")) return;

    try {
      const res = await fetch(`/api/sessions/${id}`, { method: "DELETE" });
      if (res.ok) {
        await loadSessions();
        if (activeSessionId === id) {
          router.push("/chat");
        }
      }
    } catch {}
  }

  async function startRename(id: string, currentTitle: string, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    setRenamingId(id);
    setRenameValue(currentTitle);
  }

  async function submitRename(id: string) {
    if (!renameValue.trim()) return;
    try {
      const res = await fetch(`/api/sessions/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: renameValue.trim() }),
      });
      if (res.ok) {
        await loadSessions();
      }
    } catch {}
    setRenamingId(null);
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
  }

  return (
    <div className="flex h-screen bg-[#0f0f14] overflow-hidden">
      {/* Sidebar */}
      <aside
        className={`flex flex-col bg-[#181824] border-r border-[#2a2a3a] transition-all duration-300 ease-in-out flex-shrink-0 ${
          sidebarOpen ? "w-64" : "w-0 overflow-hidden"
        }`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-4 border-b border-[#2a2a3a]">
          <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-[#7c3aed] flex-shrink-0">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span className="font-bold text-white text-sm whitespace-nowrap">
            Luxzz<span className="text-[#7c3aed]">-AI</span>
          </span>
        </div>

        {/* New Chat Button */}
        <div className="px-3 py-3">
          <button
            onClick={createSession}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl bg-[#7c3aed] hover:bg-[#9333ea] text-white text-sm font-medium transition-all duration-200 active:scale-95 hover:shadow-lg hover:shadow-purple-500/20"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <line x1="12" y1="5" x2="12" y2="19"/>
              <line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            New conversation
          </button>
        </div>

        {/* Sessions List */}
        <div className="flex-1 overflow-y-auto px-2 py-1">
          {loadingSessions ? (
            <div className="flex justify-center py-6">
              <svg className="animate-spin text-[#7c3aed]" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 12a9 9 0 11-6.219-8.56"/>
              </svg>
            </div>
          ) : sessions.length === 0 ? (
            <p className="text-[#4b5563] text-xs text-center py-6 px-2">
              No conversations yet. Start one!
            </p>
          ) : (
            <div className="space-y-0.5">
              {sessions.map((s) => (
                <div key={s.id} className="group relative">
                  {renamingId === s.id ? (
                    <div className="px-2 py-1.5">
                      <input
                        autoFocus
                        value={renameValue}
                        onChange={(e) => setRenameValue(e.target.value)}
                        onBlur={() => submitRename(s.id)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") submitRename(s.id);
                          if (e.key === "Escape") setRenamingId(null);
                        }}
                        className="w-full bg-[#0f0f14] border border-[#7c3aed] rounded-lg px-2 py-1 text-xs text-[#e5e7eb] focus:outline-none"
                      />
                    </div>
                  ) : (
                    <Link
                      href={`/chat?session=${s.id}`}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm transition-all duration-200 ${
                        activeSessionId === s.id
                          ? "bg-[#7c3aed]/20 text-white border border-[#7c3aed]/30"
                          : "text-[#9ca3af] hover:bg-[#0f0f14] hover:text-white"
                      }`}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0 opacity-60">
                        <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>
                      </svg>
                      <span className="truncate flex-1 text-xs">
                        {s.title}
                      </span>

                      {/* Action buttons */}
                      <div className="hidden group-hover:flex items-center gap-0.5 flex-shrink-0">
                        <button
                          onClick={(e) => startRename(s.id, s.title, e)}
                          className="p-1 rounded-md hover:bg-[#2a2a3a] text-[#6b7280] hover:text-[#e5e7eb] transition-colors"
                          title="Rename"
                        >
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                            <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                          </svg>
                        </button>
                        <button
                          onClick={(e) => deleteSession(s.id, e)}
                          className="p-1 rounded-md hover:bg-red-500/20 text-[#6b7280] hover:text-red-400 transition-colors"
                          title="Delete"
                        >
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <polyline points="3 6 5 6 21 6"/>
                            <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                            <path d="M10 11v6M14 11v6"/>
                          </svg>
                        </button>
                      </div>
                    </Link>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Bottom: User info + nav */}
        <div className="border-t border-[#2a2a3a] px-3 py-3 space-y-1">
          {session.role === "ADMIN" && (
            <Link
              href="/admin"
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs transition-all duration-200 ${
                pathname === "/admin"
                  ? "bg-[#7c3aed]/20 text-[#7c3aed]"
                  : "text-[#9ca3af] hover:bg-[#0f0f14] hover:text-white"
              }`}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="3" width="7" height="7"/>
                <rect x="14" y="3" width="7" height="7"/>
                <rect x="14" y="14" width="7" height="7"/>
                <rect x="3" y="14" width="7" height="7"/>
              </svg>
              Admin Panel
            </Link>
          )}

          <button
            onClick={logout}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-[#9ca3af] hover:bg-[#0f0f14] hover:text-red-400 transition-all duration-200"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Sign out
          </button>

          <div className="flex items-center gap-2 px-3 py-2">
            <div className="w-7 h-7 rounded-full bg-[#7c3aed] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
              {(session.name || session.email)[0].toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-[#e5e7eb] truncate">
                {session.name || "User"}
              </p>
              <p className="text-[10px] text-[#6b7280] truncate">{session.email}</p>
            </div>
            {session.role === "ADMIN" && (
              <span className="text-[9px] bg-[#7c3aed]/20 text-[#7c3aed] border border-[#7c3aed]/30 px-1.5 py-0.5 rounded-full flex-shrink-0">
                ADMIN
              </span>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <div className="flex items-center gap-3 px-4 py-3 border-b border-[#2a2a3a] bg-[#0f0f14] flex-shrink-0">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-xl text-[#6b7280] hover:text-white hover:bg-[#181824] transition-all duration-200 active:scale-95"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="3" y1="6" x2="21" y2="6"/>
              <line x1="3" y1="12" x2="21" y2="12"/>
              <line x1="3" y1="18" x2="21" y2="18"/>
            </svg>
          </button>

          <div className="flex-1" />

          <a
            href="https://t.me/cloudakamai"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-[#6b7280] hover:text-[#7c3aed] transition-colors duration-200 flex items-center gap-1"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <line x1="12" y1="8" x2="12" y2="12"/>
              <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            Support
          </a>
        </div>

        {/* Page content */}
        <div className="flex-1 overflow-hidden">{children}</div>
      </div>
    </div>
  );
}
