"use client";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

interface MessageBubbleProps {
  message: Message;
  isStreaming?: boolean;
}

function formatContent(content: string): string {
  // Simple markdown-like rendering
  return content
    // Code blocks
    .replace(/```(\w+)?\n?([\s\S]*?)```/g, '<pre><code>$2</code></pre>')
    // Inline code
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    // Bold
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    // Headings
    .replace(/^### (.*$)/gm, '<h3>$1</h3>')
    .replace(/^## (.*$)/gm, '<h2>$1</h2>')
    .replace(/^# (.*$)/gm, '<h1>$1</h1>')
    // Unordered lists
    .replace(/^[-*] (.*$)/gm, '<li>$1</li>')
    .replace(/((<li>.*<\/li>\n?)+)/g, '<ul>$1</ul>')
    // Numbered lists
    .replace(/^\d+\. (.*$)/gm, '<li>$1</li>')
    // Paragraphs
    .replace(/\n\n/g, '</p><p>')
    // Line breaks
    .replace(/\n/g, '<br/>')
    // Wrap in paragraph
    .replace(/^(?!<[hup])(.+)/, '<p>$1');
}

export function MessageBubble({ message, isStreaming }: MessageBubbleProps) {
  const isUser = message.role === "user";
  const formattedContent = formatContent(message.content);

  return (
    <div
      className={`flex animate-fade-in ${isUser ? "justify-end" : "justify-start"} mb-3`}
    >
      {/* AI Avatar */}
      {!isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-xl bg-[#7c3aed]/20 border border-[#7c3aed]/30 flex items-center justify-center mr-3 mt-0.5">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="#7c3aed" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      )}

      <div
        className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
          isUser
            ? "bg-[#7c3aed] text-white rounded-br-sm"
            : "bg-[#181824] border border-[#2a2a3a] text-[#e5e7eb] rounded-bl-sm"
        }`}
      >
        <div
          className="message-content"
          dangerouslySetInnerHTML={{ __html: formattedContent }}
        />
        {isStreaming && (
          <span className="inline-block w-1.5 h-4 bg-[#7c3aed] animate-pulse ml-0.5 rounded-sm align-text-bottom" />
        )}
      </div>

      {/* User Avatar */}
      {isUser && (
        <div className="flex-shrink-0 w-8 h-8 rounded-xl bg-[#2a2a3a] flex items-center justify-center ml-3 mt-0.5 text-xs font-bold text-[#9ca3af]">
          U
        </div>
      )}
    </div>
  );
}
