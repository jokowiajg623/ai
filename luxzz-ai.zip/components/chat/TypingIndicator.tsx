export function TypingIndicator() {
  return (
    <div className="flex justify-start mb-3 animate-fade-in">
      <div className="flex-shrink-0 w-8 h-8 rounded-xl bg-[#7c3aed]/20 border border-[#7c3aed]/30 flex items-center justify-center mr-3 mt-0.5">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
          <path
            d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
            stroke="#7c3aed"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <div className="bg-[#181824] border border-[#2a2a3a] rounded-2xl rounded-bl-sm px-4 py-4 flex items-center gap-1.5">
        <span className="w-2 h-2 rounded-full bg-[#7c3aed] dot-1" />
        <span className="w-2 h-2 rounded-full bg-[#7c3aed] dot-2" />
        <span className="w-2 h-2 rounded-full bg-[#7c3aed] dot-3" />
      </div>
    </div>
  );
}
