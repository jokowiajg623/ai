"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { SessionPayload } from "@/lib/auth";
import { MessageBubble } from "./MessageBubble";
import { TypingIndicator } from "./TypingIndicator";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

interface ChatInterfaceProps {
  sessionId: string;
  initialMessages: Message[];
  userSession: SessionPayload;
}

export function ChatInterface({
  sessionId,
  initialMessages,
  userSession,
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [error, setError] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingContent]);

  useEffect(() => {
    // Reset on session change
    setMessages(initialMessages);
    setStreamingContent("");
    setIsStreaming(false);
    setError(null);
    inputRef.current?.focus();
  }, [sessionId]);

  const sendMessage = useCallback(
    async (text: string) => {
      if (!text.trim() || isStreaming) return;

      const userMessage: Message = {
        id: `temp-${Date.now()}`,
        role: "user",
        content: text.trim(),
        createdAt: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, userMessage]);
      setInput("");
      setIsStreaming(true);
      setStreamingContent("");
      setError(null);

      abortRef.current = new AbortController();

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId, message: text.trim() }),
          signal: abortRef.current.signal,
        });

        if (!res.ok) {
          const data = await res.json();
          throw new Error(data.error || "Failed to send message");
        }

        const reader = res.body?.getReader();
        if (!reader) throw new Error("No response stream");

        const decoder = new TextDecoder();
        let accumulated = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split("\n");

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith("data: ")) continue;
            const data = trimmed.slice(6);

            try {
              const json = JSON.parse(data);
              if (json.error) {
                throw new Error(json.error);
              }
              if (json.done) {
                // Finalize message
                const assistantMessage: Message = {
                  id: `ai-${Date.now()}`,
                  role: "assistant",
                  content: accumulated,
                  createdAt: new Date().toISOString(),
                };
                setMessages((prev) => [...prev, assistantMessage]);
                setStreamingContent("");
                break;
              }
              if (json.content) {
                accumulated += json.content;
                setStreamingContent(accumulated);
              }
            } catch (parseError) {
              if (parseError instanceof Error && parseError.message !== "JSON parse error") {
                throw parseError;
              }
            }
          }
        }
      } catch (err) {
        if (err instanceof Error && err.name === "AbortError") return;
        const msg = err instanceof Error ? err.message : "Something went wrong";
        setError(msg);
        setMessages((prev) => prev.filter((m) => m.id !== userMessage.id));
      } finally {
        setIsStreaming(false);
        abortRef.current = null;
      }
    },
    [sessionId, isStreaming]
  );

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  }

  function adjustHeight(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setInput(e.target.value);
    const el = e.target;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  }

  function stopGeneration() {
    abortRef.current?.abort();
    setIsStreaming(false);
    setStreamingContent("");
  }

  const isEmpty = messages.length === 0 && !isStreaming;

  return (
    <div className="flex flex-col h-full bg-[#0f0f14]">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-2">
        {isEmpty && (
          <div className="flex flex-col items-center justify-center h-full text-center pb-20 animate-fade-in">
            <div className="w-16 h-16 rounded-2xl bg-[#7c3aed]/20 border border-[#7c3aed]/30 flex items-center justify-center mb-4 glow-purple">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="#7c3aed" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h2 className="text-xl font-semibold text-white mb-2">How can I help you?</h2>
            <p className="text-[#6b7280] text-sm max-w-sm">
              Ask me anything — I&apos;m powered by advanced AI models and ready to assist.
            </p>

            {/* Suggestions */}
            <div className="mt-6 grid grid-cols-2 gap-2 max-w-md w-full">
              {[
                "Explain quantum computing simply",
                "Write a Python web scraper",
                "Debug my code",
                "Summarize a long document",
              ].map((suggestion) => (
                <button
                  key={suggestion}
                  onClick={() => sendMessage(suggestion)}
                  className="text-left px-3 py-3 rounded-xl bg-[#181824] border border-[#2a2a3a] hover:border-[#7c3aed]/50 hover:bg-[#7c3aed]/5 text-[#9ca3af] hover:text-white text-xs transition-all duration-200 active:scale-95"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}

        {isStreaming && streamingContent && (
          <MessageBubble
            message={{
              id: "streaming",
              role: "assistant",
              content: streamingContent,
              createdAt: new Date().toISOString(),
            }}
            isStreaming
          />
        )}

        {isStreaming && !streamingContent && <TypingIndicator />}

        <div ref={bottomRef} />
      </div>

      {/* Error */}
      {error && (
        <div className="mx-4 mb-2 flex items-center gap-2 text-red-400 text-sm bg-red-400/10 border border-red-400/20 rounded-xl px-4 py-3 animate-fade-in">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="8" x2="12" y2="12"/>
            <line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
          <span className="flex-1">{error}</span>
          <button onClick={() => setError(null)} className="ml-auto hover:text-red-300">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      )}

      {/* Input area */}
      <div className="px-4 pb-4 flex-shrink-0">
        <div className="relative flex items-end gap-2 bg-[#181824] border border-[#2a2a3a] rounded-2xl px-4 py-3 focus-within:border-[#7c3aed]/50 transition-all duration-200">
          <textarea
            ref={inputRef}
            value={input}
            onChange={adjustHeight}
            onKeyDown={handleKeyDown}
            placeholder="Message Luxzz-AI..."
            rows={1}
            disabled={isStreaming}
            className="flex-1 bg-transparent resize-none text-[#e5e7eb] placeholder-[#4b5563] focus:outline-none text-sm leading-relaxed max-h-48 disabled:opacity-50"
            style={{ minHeight: "24px" }}
          />

          <div className="flex items-center gap-1 flex-shrink-0">
            {isStreaming ? (
              <button
                onClick={stopGeneration}
                className="w-9 h-9 flex items-center justify-center rounded-xl bg-[#2a2a3a] hover:bg-red-500/20 text-[#9ca3af] hover:text-red-400 transition-all duration-200 active:scale-95"
                title="Stop generation"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                  <rect x="6" y="6" width="12" height="12" rx="2"/>
                </svg>
              </button>
            ) : (
              <button
                onClick={() => sendMessage(input)}
                disabled={!input.trim()}
                className="w-9 h-9 flex items-center justify-center rounded-xl bg-[#7c3aed] hover:bg-[#9333ea] disabled:opacity-40 disabled:cursor-not-allowed text-white transition-all duration-200 active:scale-95 hover:shadow-lg hover:shadow-purple-500/20"
                title="Send message"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <line x1="22" y1="2" x2="11" y2="13"/>
                  <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
              </button>
            )}
          </div>
        </div>

        <p className="text-center text-[10px] text-[#4b5563] mt-2">
          Press Enter to send · Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}
