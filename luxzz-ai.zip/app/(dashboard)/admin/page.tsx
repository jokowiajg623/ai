import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { AdminPanel } from "@/components/admin/AdminPanel";
import { getSettings } from "@/lib/settings";
import { prisma } from "@/lib/prisma";

export default async function AdminPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "ADMIN") redirect("/chat");

  const [settings, totalUsers, totalSessions, totalMessages] = await Promise.all([
    getSettings(),
    prisma.user.count(),
    prisma.chatSession.count(),
    prisma.chatMessage.count(),
  ]);

  return (
    <AdminPanel
      initialSettings={settings}
      stats={{ totalUsers, totalSessions, totalMessages }}
    />
  );
}
