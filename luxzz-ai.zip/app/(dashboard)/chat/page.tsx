import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { ChatInterface } from "@/components/chat/ChatInterface";

export default async function ChatPage({
  searchParams,
}: {
  searchParams: { session?: string };
}) {
  const session = await getSession();
  if (!session) redirect("/login");

  // If no sessionId, create one or use most recent
  let sessionId = searchParams.session;

  if (!sessionId) {
    const latest = await prisma.chatSession.findFirst({
      where: { userId: session.userId },
      orderBy: { updatedAt: "desc" },
    });

    if (latest) {
      redirect(`/chat?session=${latest.id}`);
    } else {
      // Create first session
      const newSession = await prisma.chatSession.create({
        data: { userId: session.userId, title: "New Chat" },
      });
      redirect(`/chat?session=${newSession.id}`);
    }
  }

  // Verify session belongs to user
  const chatSession = await prisma.chatSession.findFirst({
    where: { id: sessionId, userId: session.userId },
    include: {
      messages: { orderBy: { createdAt: "asc" } },
    },
  });

  if (!chatSession) {
    redirect("/chat");
  }

  return (
    <ChatInterface
      sessionId={chatSession.id}
      initialMessages={chatSession.messages.map((m) => ({
        id: m.id,
        role: m.role as "user" | "assistant",
        content: m.content,
        createdAt: m.createdAt.toISOString(),
      }))}
      userSession={session}
    />
  );
}
