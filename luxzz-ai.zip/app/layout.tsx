import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Luxzz-AI — Intelligent Without Limits",
  description:
    "Luxzz-AI is a powerful AI chat platform powered by the latest language models.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
