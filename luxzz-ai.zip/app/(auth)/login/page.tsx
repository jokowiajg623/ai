import { LoginForm } from "@/components/auth/LoginForm";
import Link from "next/link";

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0f0f14] px-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#7c3aed] mb-4 glow-purple">
            <svg
              width="28"
              height="28"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
                stroke="white"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tight">
            Luxzz<span className="text-[#7c3aed]">-AI</span>
          </h1>
          <p className="text-[#9ca3af] mt-1 text-sm">Intelligent Without Limits</p>
        </div>

        {/* Card */}
        <div className="bg-[#181824] border border-[#2a2a3a] rounded-2xl p-8 shadow-2xl">
          <h2 className="text-xl font-semibold text-white mb-6">Welcome back</h2>
          <LoginForm />
          <p className="text-center text-sm text-[#9ca3af] mt-6">
            Don&apos;t have an account?{" "}
            <Link
              href="/register"
              className="text-[#7c3aed] hover:text-[#9333ea] font-medium transition-colors duration-200"
            >
              Sign up
            </Link>
          </p>
        </div>

        <p className="text-center text-xs text-[#6b7280] mt-6">
          Need help?{" "}
          <a
            href="https://t.me/cloudakamai"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#7c3aed] hover:text-[#9333ea] transition-colors duration-200"
          >
            Contact Support
          </a>
        </p>
      </div>
    </div>
  );
}
