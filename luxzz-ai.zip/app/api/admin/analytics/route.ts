import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    const session = await getSession();
    if (!session || session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const [
      totalUsers,
      totalSessions,
      totalMessages,
      recentUsers,
      messagesLast7Days,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.chatSession.count(),
      prisma.chatMessage.count(),
      prisma.user.findMany({
        orderBy: { createdAt: "desc" },
        take: 10,
        select: { id: true, name: true, email: true, role: true, createdAt: true },
      }),
      // Messages per day for last 7 days
      prisma.$queryRaw<{ date: string; count: bigint }[]>`
        SELECT 
          DATE(created_at)::text as date,
          COUNT(*) as count
        FROM chat_messages
        WHERE created_at >= NOW() - INTERVAL '7 days'
          AND role = 'user'
        GROUP BY DATE(created_at)
        ORDER BY date ASC
      `,
    ]);

    return NextResponse.json({
      stats: {
        totalUsers,
        totalSessions,
        totalMessages,
      },
      recentUsers,
      messagesLast7Days: messagesLast7Days.map((r) => ({
        date: r.date,
        count: Number(r.count),
      })),
    });
  } catch (error) {
    console.error("[ADMIN/ANALYTICS]", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
