import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { getSettings, setSetting } from "@/lib/settings";
import { z } from "zod";

const settingsSchema = z.object({
  systemPrompt: z.string().min(1).max(5000).optional(),
  model: z.string().min(1).optional(),
  temperature: z
    .number()
    .min(0)
    .max(2)
    .optional()
    .transform((v) => v?.toString()),
});

export async function GET() {
  try {
    const session = await getSession();
    if (!session || session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const settings = await getSettings();
    return NextResponse.json({ settings });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const session = await getSession();
    if (!session || session.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json();
    const parsed = settingsSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.errors[0].message },
        { status: 400 }
      );
    }

    const updates = parsed.data;
    await Promise.all(
      Object.entries(updates)
        .filter(([, v]) => v !== undefined)
        .map(([k, v]) => setSetting(k, v as string))
    );

    const settings = await getSettings();
    return NextResponse.json({ settings });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
