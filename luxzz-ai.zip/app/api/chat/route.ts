import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { chatCompletion } from "@/lib/openrouter";
import { getSettings } from "@/lib/settings";
import { rateLimit } from "@/lib/ratelimit";
import { z } from "zod";

const chatSchema = z.object({
  sessionId: z.string().min(1),
  message: z
    .string()
    .min(1, "Message cannot be empty")
    .max(10000, "Message too long"),
});

export async function POST(req: NextRequest) {
  try {
    // Auth check
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Rate limit per user
    const rl = rateLimit(`chat:${session.userId}`);
    if (!rl.success) {
      return NextResponse.json(
        {
          error: "Too many requests. Please wait a moment before sending more messages.",
          resetAt: rl.resetAt,
        },
        { status: 429 }
      );
    }

    // Validate input
    const body = await req.json();
    const parsed = chatSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.errors[0].message },
        { status: 400 }
      );
    }

    const { sessionId, message } = parsed.data;

    // Verify session belongs to user
    const chatSession = await prisma.chatSession.findFirst({
      where: { id: sessionId, userId: session.userId },
      include: {
        messages: {
          orderBy: { createdAt: "asc" },
          take: 20, // Last 20 messages for context
        },
      },
    });

    if (!chatSession) {
      return NextResponse.json(
        { error: "Chat session not found" },
        { status: 404 }
      );
    }

    // Save user message
    await prisma.chatMessage.create({
      data: {
        sessionId,
        role: "user",
        content: message.trim(),
      },
    });

    // Update session timestamp & auto-title
    if (chatSession.title === "New Chat" && chatSession.messages.length === 0) {
      const title =
        message.trim().slice(0, 50) + (message.length > 50 ? "..." : "");
      await prisma.chatSession.update({
        where: { id: sessionId },
        data: { title, updatedAt: new Date() },
      });
    } else {
      await prisma.chatSession.update({
        where: { id: sessionId },
        data: { updatedAt: new Date() },
      });
    }

    // Get settings
    const settings = await getSettings();

    // Build messages for API
    const historyMessages = chatSession.messages.map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    }));
    historyMessages.push({ role: "user", content: message.trim() });

    // Call OpenRouter with streaming
    const openRouterResponse = await chatCompletion({
      model: settings.model,
      messages: historyMessages,
      temperature: parseFloat(settings.temperature),
      systemPrompt: settings.systemPrompt,
      stream: true,
    });

    // Stream the response back and collect full content
    let fullContent = "";

    const stream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        const reader = openRouterResponse.body?.getReader();
        if (!reader) {
          controller.close();
          return;
        }

        const decoder = new TextDecoder();
        let buffer = "";

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() ?? "";

            for (const line of lines) {
              const trimmed = line.trim();
              if (!trimmed || !trimmed.startsWith("data: ")) continue;
              const data = trimmed.slice(6);
              if (data === "[DONE]") continue;

              try {
                const json = JSON.parse(data);
                const delta = json.choices?.[0]?.delta?.content;
                if (delta) {
                  fullContent += delta;
                  controller.enqueue(
                    encoder.encode(`data: ${JSON.stringify({ content: delta })}\n\n`)
                  );
                }
              } catch {
                // Skip malformed JSON lines
              }
            }
          }
        } catch (error) {
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({ error: "Stream error occurred" })}\n\n`
            )
          );
        } finally {
          reader.releaseLock();

          // Save assistant message
          if (fullContent) {
            try {
              await prisma.chatMessage.create({
                data: {
                  sessionId,
                  role: "assistant",
                  content: fullContent,
                },
              });
            } catch (e) {
              console.error("[CHAT] Failed to save assistant message:", e);
            }
          }

          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify({ done: true })}\n\n`)
          );
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
      },
    });
  } catch (error) {
    console.error("[CHAT]", error);
    const message =
      error instanceof Error ? error.message : "Internal server error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
