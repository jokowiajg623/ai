export interface ChatMessage {
  role: "user" | "assistant" | "system";
  content: string;
}

export interface OpenRouterOptions {
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  systemPrompt?: string;
  stream?: boolean;
}

const OPENROUTER_BASE = "https://openrouter.ai/api/v1";
const DEFAULT_TIMEOUT = 30000;
const MAX_RETRIES = 2;

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function chatCompletion(
  options: OpenRouterOptions,
  retryCount = 0
): Promise<Response> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    throw new Error("OPENROUTER_API_KEY is not configured");
  }

  const messages: ChatMessage[] = [];
  if (options.systemPrompt) {
    messages.push({ role: "system", content: options.systemPrompt });
  }
  messages.push(...options.messages);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), DEFAULT_TIMEOUT);

  try {
    const response = await fetch(`${OPENROUTER_BASE}/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "HTTP-Referer":
          process.env.NEXT_PUBLIC_APP_URL || "https://luxzz-ai.vercel.app",
        "X-Title": "Luxzz-AI",
      },
      body: JSON.stringify({
        model: options.model,
        messages,
        temperature: options.temperature ?? 0.7,
        stream: options.stream ?? true,
        max_tokens: 2048,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const errorText = await response.text().catch(() => "Unknown error");

      // Retry on 429 (rate limit) or 5xx
      if (
        retryCount < MAX_RETRIES &&
        (response.status === 429 || response.status >= 500)
      ) {
        const delay = Math.pow(2, retryCount) * 1000;
        await sleep(delay);
        return chatCompletion(options, retryCount + 1);
      }

      throw new Error(
        `OpenRouter API error: ${response.status} - ${errorText}`
      );
    }

    return response;
  } catch (error) {
    clearTimeout(timeoutId);

    if (error instanceof Error && error.name === "AbortError") {
      throw new Error("Request timed out. Please try again.");
    }

    if (
      retryCount < MAX_RETRIES &&
      error instanceof TypeError &&
      error.message.includes("fetch")
    ) {
      await sleep(1000 * (retryCount + 1));
      return chatCompletion(options, retryCount + 1);
    }

    throw error;
  }
}

export const DEFAULT_MODELS = [
  { id: "openai/gpt-4o", name: "GPT-4o" },
  { id: "openai/gpt-4o-mini", name: "GPT-4o Mini" },
  { id: "openai/gpt-4-turbo", name: "GPT-4 Turbo" },
  { id: "anthropic/claude-3.5-sonnet", name: "Claude 3.5 Sonnet" },
  { id: "anthropic/claude-3-haiku", name: "Claude 3 Haiku" },
  { id: "google/gemini-pro-1.5", name: "Gemini Pro 1.5" },
  { id: "meta-llama/llama-3.1-70b-instruct", name: "Llama 3.1 70B" },
  { id: "mistralai/mixtral-8x7b-instruct", name: "Mixtral 8x7B" },
];
