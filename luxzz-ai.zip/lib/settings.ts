import { prisma } from "./prisma";

export const DEFAULT_SETTINGS = {
  systemPrompt:
    "You are Luxzz-AI, an intelligent and helpful AI assistant. You provide clear, accurate, and thoughtful responses. Be concise yet comprehensive.",
  model: "openai/gpt-4o-mini",
  temperature: "0.7",
};

export async function getSetting(key: string): Promise<string | null> {
  try {
    const setting = await prisma.setting.findUnique({ where: { key } });
    return setting?.value ?? null;
  } catch {
    return null;
  }
}

export async function getSettings(): Promise<Record<string, string>> {
  try {
    const settings = await prisma.setting.findMany();
    const map: Record<string, string> = { ...DEFAULT_SETTINGS };
    for (const s of settings) {
      map[s.key] = s.value;
    }
    return map;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  await prisma.setting.upsert({
    where: { key },
    update: { value },
    create: { key, value },
  });
}
