import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding database...");

  // Create admin user
  const adminPassword = await bcrypt.hash("Admin123!", 12);
  const admin = await prisma.user.upsert({
    where: { email: "admin@luxzz-ai.com" },
    update: {},
    create: {
      email: "admin@luxzz-ai.com",
      name: "Admin",
      password: adminPassword,
      role: "ADMIN",
    },
  });

  console.log("✅ Admin user:", admin.email);

  // Seed default settings
  const defaults = [
    {
      key: "systemPrompt",
      value:
        "You are Luxzz-AI, an intelligent and helpful AI assistant. You provide clear, accurate, and thoughtful responses. Be concise yet comprehensive.",
    },
    { key: "model", value: "openai/gpt-4o-mini" },
    { key: "temperature", value: "0.7" },
  ];

  for (const setting of defaults) {
    await prisma.setting.upsert({
      where: { key: setting.key },
      update: {},
      create: setting,
    });
  }

  console.log("✅ Default settings seeded");
  console.log("\n🎉 Seed complete!");
  console.log("   Admin: admin@luxzz-ai.com");
  console.log("   Password: Admin123!");
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
